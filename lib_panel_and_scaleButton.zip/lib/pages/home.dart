import 'package:flutter/material.dart';
import 'package:flutter_scale_tap/flutter_scale_tap.dart';
import 'package:restaurant_proto_app/widgets/slidingPanel/panel.dart';

class Home extends StatefulWidget {
  const Home({ Key? key }) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  double _opacity = 0;
  PanelController panelController = PanelController();


  @override
  Widget build(BuildContext context) {
  return Scaffold(
    body: SlidingPanel(
      renderPanelSheet: false,
      panel: _floatingPanel(),
      minWidth: 70.0, // Setting up the width of shown panel while collapsed
      maxWidth: 350.0, // Setting up the length of the panel 
      onPanelSlide: (position){
        setState(() {
          _opacity = position;
        });
      },
      slideDirection: SlideDirection.RIGHT,
      body: Center(
        child: Container(
          height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
          child: SlidingPanel(
            controller: panelController,
          renderPanelSheet: false,
          panel: _floatingPanel2(),
          minWidth: 0.0, // Setting up the width of shown panel while collapsed
          maxWidth: 350.0, // Setting up the length of the panel 
          onPanelSlide: (position){
            setState(() {
              _opacity = position;
            });
          },
          slideDirection: SlideDirection.LEFT,
          body: Stack(
            children: [
              Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                child: Center(
                  child: ScaleTap(
                    opacityMinValue: 1,
                    scaleMinValue: 0.85,
                    onPressed: (){
                      panelController.open();
                    },
                    child: Container(
                      color: Colors.blue,
                      height: 200,
                      width: 250,
                      child: Stack(
                        children: [
                          Positioned(
                            bottom: 15,
                            right: 15,
                            child: Container(
                              height: 85,
                              width: 85,
                              child: Placeholder()
                            )
                          )
                        ],
                      )
                    ),
                  )
                ),
              ),
              Offstage(
                offstage: _opacity == 0,
                child: GestureDetector(
                  onTap: () => panelController.close(),
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    color: Colors.black.withOpacity(_opacity / 2),
                  ),
                ),
              ),
            ],
          ),
    ),
        ),
      ),
    ),
  );
}

Widget _someWidget(){
  return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: 200,
                    height: 100,
                    color: Colors.blue,
                  ),
                ),
              ],
            );
}


Widget _floatingPanel(){
  return Padding(
    padding: const EdgeInsets.only(top: 30), //Padding from top
    child: Container(
      height: MediaQuery.of(context).size.height * .85, // Height of the panel
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(35.0)),
        boxShadow: [
          BoxShadow(
            blurRadius: 20.0,
            color: Colors.grey,
          ),
        ]
      ),
      margin: const EdgeInsets.fromLTRB(1040, 100, 24, 10), //Defining The margins of the panel where 1040 helping to define proper width of the panel
      child: ClipRRect(
        borderRadius: BorderRadius.circular(35.0),
        child: Opacity(
          opacity: _opacity,
          child: SingleChildScrollView( // Body of the panel
            child: Column(
              children: [
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

Widget _floatingPanel2(){
  return Padding(
    padding: const EdgeInsets.only(top: 30),  //Padding from top
    child: Container(
      height: MediaQuery.of(context).size.height * .85, // Height of the panel
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(35.0)),
        boxShadow: [
          BoxShadow(
            blurRadius: 20.0,
            color: Colors.grey,
          ),
        ]
      ),
      margin: const EdgeInsets.fromLTRB(24, 100, 1040, 10), //Defining The margins of the panel where 1040 helping to define proper width of the panel
      child: ClipRRect(
        borderRadius: BorderRadius.circular(35.0),
        child: Opacity(
          opacity: _opacity,
          child: SingleChildScrollView( // Body of the panel
            child: Column(
              children: [
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
                _someWidget(),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
}